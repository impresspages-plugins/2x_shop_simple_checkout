Example to catch SimpleCheckout plugin order
Compatible with version 2.4+


HOW TO INSTALL
===============
1. Upload this plugin "example" folder to "ip_plugins/" directory of your website.
2. Login to administration area
3. Go to "Developer -> Modules" and press "install".

Read and change to your needs system.php file