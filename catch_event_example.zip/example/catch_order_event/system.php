<?php
/**
 * @package ImpressPages
 * @copyright   Copyright (C) 2011 ImpressPages LTD.
 * @license see ip_license.html
 */
namespace Modules\example\catch_order_event;



class System{

    function init(){
        global $dispatcher;

        $dispatcher->bind(\Modules\shop\simple_checkout\EventNewOrder::EVENT_NEW_ORDER, array($this, 'processOrder'));


    }

    public function processOrder(\Modules\shop\simple_checkout\EventNewOrder $event)
    {


        $orderData = array(
            'price' => $event->getPrice(),
            'currency' => $event->getCurrency(),
            'userId' => $event->getUserId(), //might be null if user buys without registration
            'buyerEmail' => $event->getBuyerEmail(), //supplied by PayPal or Google. May differ from your system user email
            'testMode' => $event->getTest(), //DEVELOPMENT_ENVIRONMENT constant in ip_config.php
            'productId' => $event->getProductId() //Product ID is unique number that identifies product you sell. You enter product id manually in each widget.
        );


        //perform required actions here
        global $log;
        $log->log('example/catch_order_event', 'Catched order', json_encode($orderData));

    }


}


